�@�@�@==================
�@�@�@Fat32Formatter 1.1
�@�@�@==================

All About
=========
 Fat32Formatter is freeware and written by TOKIWA to format drive larger than 32GB  to FAT32, 
 which means it can walk around the OS restriction that you can format drive to FAT32 only the size up to 32GB on Windows2000/XP/Vista/7.  

Compatible operating systems
============================
 Windows2000/XP/Vista/7

Key-features
============
 1 simple and instructive UI 
 2 it can set and delete partitions as well
 3 neither installation nor DLLs is needed
 4 Windows 7 supported

How to use
==========
 You can understand it intuitively through simple UI and balloon tips. So there is no need for instructions.
 Also you can update Fat32Formatter to new version if available through "Version info" of system menu. 

Install/Un-install
==================
 Fat32Formatter doesn't need to be installed. Just unpack the archive you downloaded and it's runnable.
 Fat32Formatter doesn't install anything, so neither registry entries nor initialization files are left on your computer once you delete the directory of Fat32Formatter.


License
=======
Copyright(C)2012, TOKIWA
All rights reserved.

Redistribution and use in binary forms
are permitted provided that the following conditions are met:

- Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.
- Neither the name of TOKIWA nor the names of its contributors may be used
  to endorse or promote products derived from this software without specific
  prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.

Mail
====
 admin@tokiwa.qee.jp
Comments and suggestions are always welcome!

Home 
====
 http://tokiwa.qee.jp/EN/Fat32Formatter/index.html

Donation 
========
 If you like Fat32Formatter, please donate from the url above.
 It would help us go on making good freeware!
 
History
=======
�@2007/11/22  v1.0 first version
�@20012/1/25  v1.1 Windows7 supported, improved UI